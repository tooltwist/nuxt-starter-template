// See https://github.com/nuxt/nuxt.js/issues/174#issuecomment-275939000
// import Vue from 'vue'
// import Icon from 'vue-awesome/components/Icon.vue'
// require('vue-awesome/icons')
//
// console.log('vue-orsum 1')
// Vue.component('icon', Icon)
// console.log('vue-orsum 2', Icon)
