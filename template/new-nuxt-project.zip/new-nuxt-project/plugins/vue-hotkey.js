import Vue from 'vue'
import VueHotkey from 'v-hotkey'

Vue.use(VueHotkey)
