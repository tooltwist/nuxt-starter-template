<template>
  <authservice-bounce-component/>
</template>
