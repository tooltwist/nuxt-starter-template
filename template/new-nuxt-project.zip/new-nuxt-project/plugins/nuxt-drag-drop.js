import Vue from 'vue'

// Drag and drop
import { Drag, Drop } from 'vue-drag-drop';
Vue.component('drag', Drag);
Vue.component('drop', Drop);
